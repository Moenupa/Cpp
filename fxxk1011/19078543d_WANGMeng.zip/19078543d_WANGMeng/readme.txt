GENERAL INFORMATION
project: TTT Game Design
name: WANG Meng
ID: 19078543D
Date: May 25, 2020

FILES INCLUDED

assignextra_main.cpp
                        Main Program Controlling the Workflow in C++
                        Environment: C++14, gcc 8.1.0

tictactoe.cpp
                        C++ File Implementing the Whole Tic-Tac-Toe Game
                        Environment: C++14, gcc 8.1.0

tictactoe.h
                        Header File Implementing the Whole Tic-Tac-Toe Game
                        Environment: C++14, gcc 8.1.0

assignextra_main_out.pdf
                        Output Sample in Graphs
                        Source Code Outputs are all Integrated into it

assignextra_design_notes.pdf
                        Notes and Reflections of Designing

assignextra_main_sample.exe
                        Sample Build Exe of the source code
                        Run/Test in Bash/Powershell/Cmd with the ./ command
                        DO NOT run in internal consoles(like vscode internal console)
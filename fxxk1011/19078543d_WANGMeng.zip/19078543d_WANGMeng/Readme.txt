GENERAL INFORMATION
project: 723 Cafe Order System
name: WANG Meng
ID: 19078543D
Date: May 21, 2020

FILES INCLUDED

assign1_main.cpp
                        Source Code in C++
                        Environment: C++14, gcc 8.1.0

assign1_main_out.pdf
                        Output Sample in Graphs

notes_to_owner.pdf
                        Notes to Owner

user_guide.pdf
                        Step-to-Step Procedure Details

assign1_main_sample.exe
                        Sample Build Exe of the source code
                        Run/Test in Bash/Powershell/Cmd with the ./ command
                        DO NOT run in internal consoles(like vscode internal console)